module.exports = {
    routes: {},
    currentIndex: {}
}